package common;

/*
 * Simple interface off FFT.
 *  
 */
public interface IFFT {
	public byte[] transformInFreqeuncy(byte[] img);
	public byte[] inverse(byte[] freqImg);	
}
