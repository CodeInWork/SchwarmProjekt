package simple.test;

import java.awt.image.BufferedImage;
import java.awt.image.DataBufferByte;
import java.io.ByteArrayInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.imageio.ImageIO;
import javax.sound.sampled.AudioFileFormat;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;

/*
 * First class to write imagedata directly as data to audiofile.
 */
public class ImageToWave {
	public static String pathRes = "C:/Users/Johannes/Documents/Projects/ImgAud/ImagAudNative/res/"; 
	public static String pathResults = "C:/Users/Johannes/Documents/Projects/ImgAud/ImagAudNative/results/";
	public static String pathTmp = "C:/Users/Johannes/Documents/Projects/ImgAud/ImagAudNative/tmp/";
	public static String testfilename = "lena.jpg";
	public static String resfile = "output_lena.wav";
	
	private static byte[] pixels;
	
	public static void main(String[] args) {
		try {
			System.out.println("Start image reading...");
			File f = new File(pathRes + testfilename);
			BufferedImage bimg = ImageIO.read(f);
			pixels = ((DataBufferByte) bimg.getRaster().getDataBuffer()).getData();
			// get image data
			
			// edit data
			System.out.println("Start editing data...");

			// save audio
			System.out.println("Start saveaudiofile...");
			InputStream b_in = new ByteArrayInputStream(pixels);
			DataOutputStream dos = new DataOutputStream(new FileOutputStream(
			                 pathTmp + "audiotmp.bin"));
			dos.write(pixels);
			AudioFormat format = new AudioFormat(44100f, 16, 2, true, false);
			AudioInputStream stream = new AudioInputStream(b_in, format,
			        		  pixels.length);
			File resultFile = new File(pathResults + resfile);
			          
			int writedBytes = AudioSystem.write(stream, AudioFileFormat.Type.WAVE, resultFile);
			System.out.println("writed bytes: " + writedBytes);
			dos.close();
		} catch (IOException e) {
			e.printStackTrace();
		} 
	}

}
