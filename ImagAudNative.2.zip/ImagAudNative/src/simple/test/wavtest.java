package simple.test;

import java.io.ByteArrayInputStream;
import java.io.File;

import javax.sound.sampled.AudioFileFormat;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;

public class wavtest {

	
	
	public static void main(String[] args) {
		try {
			// create datablock
			byte[] pcm_data= new byte[44100*2];
			// setsampling rate
	        double L1      = 44100.0/440.0;
	        double L2      = 44100.0/455.0;
	        
	        // fill datablock
	        for(int i=0;i<pcm_data.length;i++){
	        	// ampltude * sin( frequenz * (sample) * periode + phase);
	        	pcm_data[i]=  (byte)(10*Math.sin( (i/L1) * Math.PI * (i /(Math.PI*2))));
	        	pcm_data[i]+= (byte)(55*Math.sin( (i/L2) * Math.PI));
	        }
	        
	        // set wav header
	        AudioFormat frmt= new AudioFormat(44100, 8, 1, true, false);
	        // save data
	        AudioInputStream ais = new AudioInputStream(
	                   new ByteArrayInputStream(pcm_data)
	                  ,frmt
	                  ,pcm_data.length);
	        AudioSystem.write(ais, AudioFileFormat.Type.WAVE, new File(ImageToWave.pathResults + ImageToWave.resfile));
	        
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
