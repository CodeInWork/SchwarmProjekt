package simple.experiment.tunetest;

import java.awt.Dimension;

import javax.swing.JFrame;

public class TuneTest extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private VisualPanel p = new VisualPanel();
	private ControlPanel cp = new ControlPanel();
	
	public TuneTest() {
		//p.setLayout(new BoxLayout(p));
		this.getRootPane().add(p);
		this.getRootPane().add(cp);
	}
	
	public static void main(String[] args) {
		TuneTest t = new TuneTest();
		t.setSize(new Dimension(400, 500));
		t.setVisible(true);
	}

}
