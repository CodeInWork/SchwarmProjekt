package simple.experiment.tunetest;

import java.awt.GridLayout;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

public class ControlPanel extends JPanel implements DocumentListener{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private JLabel aLabel, pLabel, fLabel;
	private JTextField aField, pField, fField;
	
	public ControlPanel() {
		aLabel = new JLabel("Amplitude");
		pLabel = new JLabel("Phase");
		fLabel = new JLabel("Frequency");
		aField = new JTextField();
		pField = new JTextField();
		fField = new JTextField();
		
		aField.getDocument().addDocumentListener(this);
		fField.getDocument().addDocumentListener(this);
		pField.getDocument().addDocumentListener(this);
		
		GridLayout gl = new GridLayout(1,6);
		this.setLayout(gl);
		this.add(aLabel);
		this.add(aField);
		this.add(pLabel);
		this.add(pField);
		this.add(fLabel);
		this.add(fField);
	}

	@Override
	public void changedUpdate(DocumentEvent e) {
		
		// fire event to visuapanel; 
		
	}

	@Override
	public void insertUpdate(DocumentEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void removeUpdate(DocumentEvent e) {
		// TODO Auto-generated method stub
		
	}
}
