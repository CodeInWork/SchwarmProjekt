package simple.experiment.tunetest;

import java.awt.Graphics;

import javax.swing.JPanel;

public class VisualPanel extends JPanel {
	private static final long serialVersionUID = 1L;
	private double a = 1;
	private double freq = 1;
	private double tast = 44100;
	private int maxX = 1000, maxY = 1000;
	
	@Override
	public void paint(Graphics g) {
		double rate = tast/440.0;
		for (int i = 0; i < tast; i+=rate) {
			int t_s = i;
			int t_e = i+1;
			int y_s = (int) (a * Math.sin(freq * t_s * Math.PI));
			int y_e = (int) (a * Math.sin(freq * t_e * Math.PI));
			g.drawLine(t_s, y_s, t_e, y_e);
		}
		super.paint(g);
	}

	public void setA(double a) {
		this.a = a;
	}

	public void setFreq(double freq) {
		this.freq = freq;
	}

	public void setTast(double tast) {
		this.tast = tast;
	}

	public int getMaxX() {
		return maxX;
	}

	public void setMaxX(int maxX) {
		this.maxX = maxX;
	}

	public int getMaxY() {
		return maxY;
	}

	public void setMaxY(int maxY) {
		this.maxY = maxY;
	}
}
