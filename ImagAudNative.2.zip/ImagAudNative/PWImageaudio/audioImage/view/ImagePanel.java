package audioImage.view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferByte;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.lang.Thread.State;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import audioImage.events.IImageChangedListener;
import audioImage.events.ImageChangedEvent;
import audioImage.model.IInputMask;
import audioImage.model.readmask.SimpleMask;
import audioImage.model.shapes.IShape;

public class ImagePanel extends JPanel {
	private static final long serialVersionUID = 1L;
	private List<IImageChangedListener> listener = new ArrayList<IImageChangedListener>();
	
	// our drawingelements
	private volatile List<IShape> shapes = new ArrayList<IShape>();
	private List<IShape> outtaShapes = Collections.synchronizedList(new ArrayList<IShape>());
		
	public BufferedOutputStream audiostream = new BufferedOutputStream(new ByteArrayOutputStream());
	
	public ImagePanel(int width, int height) {
		setBorder(new EmptyBorder(10,10,10,10));
		setName("viewpanel");
		setPreferredSize(new Dimension(width, height));
		setBackground(Color.white);
		setDoubleBuffered(true);
		mask = new SimpleMask();
		metro = new Metronome();
	}
		
	@Override
	public void paintComponent(Graphics g) {	
		super.paintComponent(g);
				
		// draw shapes
		for (IShape s : shapes) {
			s.paintShape(g);
			if (s.isOut()) { outtaShapes.add(s); }
		}
		
		// remove non visible shapes
		for (IShape s : outtaShapes) {
			shapes.remove(s);
		}
		
		outtaShapes.clear();
				
		// release graphic
		g.dispose();
	}
	
	public synchronized void addShape(IShape s) {
		shapes.add(s);
	}
	
	// Metronome fcts
	private boolean isRunning = false;
	private Metronome metro;
	private IInputMask mask;
	private byte[] maskdata;
	
	class Metronome extends Thread {
		@Override
		public void run() {
			while (isRunning) {
				// filter image
				BufferedImage maskImg = mask.filterImage(ImagePanel.this);
				maskdata = ((DataBufferByte)maskImg.getRaster().getDataBuffer()).getData();
				try {
					audiostream.write(maskdata);
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				notifyListener();
				
				// transform shapes
				for (IShape f : shapes) {
					f.shift();
				}
				
				repaint();
				
				// sleep 
				try {
					Thread.sleep(1);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}	
		}
	}
	
	public void play() {
		isRunning = true;
		if (metro.getState()!=State.NEW) {
			metro.interrupt();
			metro = new Metronome();
		} 
		metro.start();
	}
	
	public void pause() {
		isRunning = false;
	}
	// ----------------
		
	// listener fcts
	public void addListener(IImageChangedListener l) {
		listener.add(l);
	}
		
	private void notifyListener() {
		for (IImageChangedListener l : listener) {
			l.notify(new ImageChangedEvent(this, maskdata));
		}
	}
	// --------------- \\
}
