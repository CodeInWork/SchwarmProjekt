package audioImage.view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class ToolControlView extends JPanel {
	private static final long serialVersionUID = -7075878958859266162L;
	//private final static String ICONPATH = "res/";
	
	private JPanel paintpanel = new JPanel();
	private JPanel audiopanel = new JPanel();
	
	// musicflow controlbtn
	private JButton startBtn = new JButton(),
			pauseBtn = new JButton();
	
	// draw btns
	private JButton circleBtn = new JButton("C"),
			pointBtn = new JButton("P");
	
	public ToolControlView(int width, int height) {
		setBorder(new EmptyBorder(1, 1, 1, 1));
		setBackground(Color.GRAY);
		
		buildPaintButtonGroup();
		buildAudioButtonGroups();
				
		BorderLayout bl = new BorderLayout(0,5);
		bl.addLayoutComponent(audiopanel, BorderLayout.PAGE_END);
		bl.addLayoutComponent(paintpanel, BorderLayout.PAGE_START);

		add(paintpanel);
		add(audiopanel);
		
		startBtn.setActionCommand("start");
		pauseBtn.setActionCommand("pause");
		circleBtn.setActionCommand("circle");
		pointBtn.setActionCommand("point");
	}
	
	private void buildAudioButtonGroups() {
		try {
			ImageIcon playIcon = new ImageIcon(ImageIO.read(new File("C:/Users/Johannes/Documents/Projects/ImgAud/ImagAudNative/PWImageaudio/audioImage/view/res/play_scale.png")));
			ImageIcon pauseIcon = new ImageIcon(ImageIO.read(new File("C:/Users/Johannes/Documents/Projects/ImgAud/ImagAudNative/PWImageaudio/audioImage/view/res/pause_scale.png")));
			startBtn.setIcon(playIcon);
			pauseBtn.setIcon(pauseIcon);
			
			startBtn.setPreferredSize(new Dimension(20,20));
			pauseBtn.setPreferredSize(new Dimension(20,20));			
		} catch (IOException e) {
			startBtn.setText("Play");
			e.printStackTrace();
		}
		
		startBtn.setToolTipText("Play");
		pauseBtn.setToolTipText("Pause");
		
		ButtonGroup playBtnGroup = new ButtonGroup();
		playBtnGroup.add(startBtn);
		playBtnGroup.add(pauseBtn);
		GridLayout gl = new GridLayout(1, 3);
		gl.setHgap(10);
		audiopanel.setLayout(gl);
		audiopanel.add(startBtn);
		audiopanel.add(pauseBtn);
		audiopanel.setOpaque(false);
		audiopanel.setBackground(new Color(0,0,0,0));
	}

	private void buildPaintButtonGroup() {
		circleBtn.setToolTipText("Circle");
		pointBtn.setToolTipText("Point");
		circleBtn.setPreferredSize(new Dimension(20, 20));
		pointBtn.setPreferredSize(new Dimension(20, 20));
		
		paintpanel.setLayout(new GridLayout(1,2));
		paintpanel.add(circleBtn);
		paintpanel.add(pointBtn);
		paintpanel.setOpaque(false);
		paintpanel.setBackground(new Color(0,0,0,0));
	}
	
	public void setBtnListener(ActionListener btnListener) {
		startBtn.addActionListener(btnListener);
		pauseBtn.addActionListener(btnListener);
		pointBtn.addActionListener(btnListener);
		circleBtn.addActionListener(btnListener);
	}

	public JButton getStartBtn() {
		return startBtn;
	}

	public JButton getPauseBtn() {
		return pauseBtn;
	}

	public JButton getCircleBtn() {
		return circleBtn;
	}

	public JButton getPointBtn() {
		return pointBtn;
	}
}
