package audioImage.model;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.SourceDataLine;

import audioImage.events.IImageChangedListener;
import audioImage.events.ImageChangedEvent;
import audioImage.model.audioconverter.SimpleImageAudioConverter;

public class AudioOutput implements IImageChangedListener {
	private AudioFormat audiofmt; 
	private IImageDataConverter converter;
	private SourceDataLine dataline;
	
	public AudioOutput() {
		try {
			audiofmt = new AudioFormat(44100, 8, 2, true, false);
			dataline = AudioSystem.getSourceDataLine(audiofmt);
			dataline.open(audiofmt);
			converter = new SimpleImageAudioConverter();
		} catch (LineUnavailableException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void notify(ImageChangedEvent e) {
		byte[] data = e.getImageData();
		dataline.write(converter.convertImageData(data), 0, data.length);
	}
	
	public void stopSoundLine() {
		dataline.stop();
	}
	
	public void startSoundLine() {
		dataline.start();
	}
}
