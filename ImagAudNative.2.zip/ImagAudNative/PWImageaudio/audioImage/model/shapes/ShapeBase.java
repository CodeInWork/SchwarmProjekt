package audioImage.model.shapes;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;

public abstract class ShapeBase implements IShape {
	protected Point center;
	protected Color color;
	
	public ShapeBase(Point center, Color color) {
		this.center = center;
		this.color = color;
	}
	
	@Override
	public void shift() {
		center.translate(-1, 0);
	}
	
	@Override
	public abstract void paintShape(Graphics g);
}
