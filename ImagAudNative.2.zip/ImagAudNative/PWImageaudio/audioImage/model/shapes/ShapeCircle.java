package audioImage.model.shapes;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;

public class ShapeCircle extends ShapeBase {
	private int r = 5;
		
	public ShapeCircle() { super(new Point(0,0), Color.black);	}
	
	public ShapeCircle(Point center, Color c) {
		super(center, c);
	}

	@Override
	public boolean isOut() {
		return center.x <= -10;
	}

	@Override
	public void paintShape(Graphics g) {
		if (center.x >= r && center.y>=r) {
			g.setColor(color);
			g.drawArc(center.x, center.y, r, r, 0, 360);
		}
	}

}
