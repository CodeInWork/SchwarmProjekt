package audioImage.model.shapes;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;

public class ShapePoint extends ShapeBase {

	public ShapePoint(Point p, Color c) {
		super(p, c);
	}
	
	@Override
	public boolean isOut() {
		return center.x < -2;
	}

	@Override
	public void paintShape(Graphics g) {
		g.setColor(Color.black);
		g.fillRect(center.x, center.y, 2, 2);
		
	}

}
