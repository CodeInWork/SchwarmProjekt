package audioImage.model.shapes;

import java.awt.Graphics;

public interface IShape {
	public void paintShape(Graphics g);
	public void shift();
	public boolean isOut();
}
