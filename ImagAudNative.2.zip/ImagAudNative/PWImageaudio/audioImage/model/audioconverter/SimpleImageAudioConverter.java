package audioImage.model.audioconverter;

import java.util.Arrays;

import audioImage.model.IImageDataConverter;

public class SimpleImageAudioConverter implements IImageDataConverter {
	private int amplitude = 10;
	
	
	@Override
	public byte[] convertImageData(byte[] data) {
		int datasize = data.length;
		byte[] pcm_data = Arrays.copyOf(data, 44100);
		
		// setsampling rate
		double L1 = datasize / (datasize / 100);
        //double L1      = 44100.0/440.0;
        
        // fill datablock
        for(int i=0;i<pcm_data.length;i++){
        	// amplitude * sin( frequenz * (sample) * periode + phase);
        	pcm_data[i]=  (byte)(amplitude* Math.sin(L1 * Math.PI * (i /(Math.PI * 8))));
        }
		return pcm_data;
	}

}
