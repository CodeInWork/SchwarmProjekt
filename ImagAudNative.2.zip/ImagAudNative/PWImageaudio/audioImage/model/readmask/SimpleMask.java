package audioImage.model.readmask;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

import audioImage.model.IInputMask;
import audioImage.view.ImagePanel;

public class SimpleMask implements IInputMask {

	@Override
	public BufferedImage filterImage(ImagePanel p) {
		BufferedImage img = new BufferedImage(3, p.getHeight(), BufferedImage.TYPE_4BYTE_ABGR);
		Graphics g = img.getGraphics();
		p.print(g);
		g.dispose();
		return img;
	}

	@Override
	public void paintMask(Graphics g, int height) {
		g.setColor(new Color(11, 200, 11));
		g.fillRect(0, 0, 3, height);		
	}

}
