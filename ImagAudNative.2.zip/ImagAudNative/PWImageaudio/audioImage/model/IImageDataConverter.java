package audioImage.model;

public interface IImageDataConverter {
	public byte[] convertImageData(byte[] data);
}
