package audioImage.model;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

import audioImage.view.ImagePanel;

public interface IInputMask {
	public BufferedImage filterImage(ImagePanel img);
	public void paintMask(Graphics g, int height);
}
