package audioImage.model;

import java.awt.Color;

public class ToolSettings {
	public static Color selectedColor;
}
