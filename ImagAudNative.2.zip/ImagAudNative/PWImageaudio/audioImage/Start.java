package audioImage;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.UIManager;

import audioImage.controller.AudioImageController;
import audioImage.model.AudioOutput;
import audioImage.view.ImagePanel;
import audioImage.view.ToolControlView;


public class Start extends JFrame {
	private static final long serialVersionUID = 6910930883738792181L;
	private ImagePanel imagePanel;
	private ToolControlView control;
	
	private AudioOutput output;
		
	private int maxHeight = 400;
	private int maxWidth = 700;
	
	public Start() {
		// set win properties
		super("AudioImagePlayer");
		setSize(new Dimension(maxWidth, maxHeight));
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setResizable(false);
		
		// wireup components
		imagePanel = new ImagePanel(maxWidth - 100, maxHeight);
		control = new ToolControlView(0, maxHeight);
		
		// create models 
		output = new AudioOutput();
				
		// wireup controller
		new AudioImageController(imagePanel, control, output);
		
		// added to mainframe
		BorderLayout gl = new BorderLayout();
		setLayout(gl);
		add(imagePanel);
		add(control);
		gl.addLayoutComponent(imagePanel, BorderLayout.WEST);
		
		// show
		pack();
		setVisible(true);
	}
	
	public static void main(String[] args) {
		 try {
	            // Set System L&F
	        UIManager.setLookAndFeel(
	            UIManager.getCrossPlatformLookAndFeelClassName());
	    } catch (Exception e) {
	    	e.printStackTrace();
	    }
		 
		EventQueue.invokeLater(new Runnable() {
	            
			@Override
	        public void run() {                
				JFrame ex = new Start();
	            ex.setVisible(true);                
	        }
	    });
	}
}
