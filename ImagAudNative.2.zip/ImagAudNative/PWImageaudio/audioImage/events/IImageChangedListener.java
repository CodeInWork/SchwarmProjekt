package audioImage.events;

import java.util.EventListener;

public interface IImageChangedListener extends EventListener {
	public void notify(ImageChangedEvent e);
}
