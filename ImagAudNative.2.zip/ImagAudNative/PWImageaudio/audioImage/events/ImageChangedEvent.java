package audioImage.events;

import java.util.EventObject;


public class ImageChangedEvent extends EventObject {
	private static final long serialVersionUID = 6146255408904628711L;
	private byte[] imageData;
	
	public ImageChangedEvent(Object sender, byte[] imagedata) {
		super(sender);
		this.imageData = imagedata;
	}

	public byte[] getImageData() {
		return imageData;
	}
}
