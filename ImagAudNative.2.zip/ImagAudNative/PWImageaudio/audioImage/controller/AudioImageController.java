package audioImage.controller;

import java.awt.Color;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;

import javax.swing.event.MouseInputListener;

import audioImage.model.AudioOutput;
import audioImage.model.ToolSettings;
import audioImage.model.shapes.ShapeBase;
import audioImage.model.shapes.ShapeCircle;
import audioImage.model.shapes.ShapePoint;
import audioImage.view.ImagePanel;
import audioImage.view.ToolControlView;

public class AudioImageController implements MouseInputListener, ActionListener {
	// Views
	private ImagePanel imageView;
	private ToolControlView controlView;
	// models
	private AudioOutput audioModel;
	
	// selected paintcomp
	private Class<? extends ShapeBase> currentForm = ShapePoint.class;
	
	public AudioImageController(ImagePanel imageView, ToolControlView controlView, AudioOutput audioModel) {
		this.imageView = imageView;
		this.controlView = controlView;
		this.audioModel = audioModel;
		// wireup listener
		
		this.imageView.addListener(this.audioModel);		
		this.imageView.addMouseListener(this);
		this.controlView.setBtnListener(this);
		
		ToolSettings.selectedColor = Color.black;
	}
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		String cmd = arg0.getActionCommand();
		
		switch (cmd) {
			case "circle":
				System.out.println("circle");
				currentForm = ShapeCircle.class;
				break;
			case "point":
				System.out.println("point");
				currentForm = ShapePoint.class;
				break;
			case "color":
				// open color dialog
				break;
			case "start":
				System.out.println("start");
				imageView.play();
				audioModel.startSoundLine();
				controlView.getPauseBtn().setEnabled(true);
				break;
			case "pause":
				System.out.println("pause");
				imageView.pause();
				audioModel.stopSoundLine();
				break;
			default:
				System.out.println("hmm... nothing");
		}
	}
	
	@Override
	public void mouseClicked(MouseEvent e) {
		Object src = e.getSource();
		if (src.equals(imageView)) {
			ShapeBase s;
			try {
				s = currentForm.getConstructor(Point.class, Color.class).newInstance(new Point(e.getX(), e.getY()), ToolSettings.selectedColor);
				imageView.addShape(s);
				imageView.repaint();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// Do nothing
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// Do nothing
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// Do nothing
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// Do nothing
	}

	@Override
	public void mouseDragged(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseMoved(MouseEvent arg0) {
		// Do nothing
	}
}
