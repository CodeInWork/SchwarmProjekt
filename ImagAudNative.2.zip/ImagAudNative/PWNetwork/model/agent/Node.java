package model.agent;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.util.ArrayList;
import java.util.List;

public class Node implements IAgent {
	public static float treshold = 1;
	
	public Point center;
	public List<Node> neighbour = new ArrayList<Node>();
	private Color color;
		
	
	public Node(Point c) {
		this.center = c;
		this.color = Color.DARK_GRAY;
	}

	@Override
	public void doInteraction() {
		int n_count = neighbour.size();
		
		if (n_count> Node.treshold) {
			// play sound
		}
		
		color = new Color(255 / n_count);
	}

	@Override
	public void drawAgent(Graphics g) {
		g.setColor(color);
		g.fillArc(center.x - 5, center.y - 5, 15, 15, 0, 270);		
	}
	
	
}
