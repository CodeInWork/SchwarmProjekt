package model.agent;

import java.awt.Graphics;

public interface IAgent {
	public void doInteraction();
	public void drawAgent(Graphics g);
}
