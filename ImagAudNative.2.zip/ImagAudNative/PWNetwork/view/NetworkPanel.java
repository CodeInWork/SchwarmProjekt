package view;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.swing.JPanel;

import model.agent.Node;

public class NetworkPanel extends JPanel {
	private static final long serialVersionUID = -750754383194574799L;
	private List<Node> network = new ArrayList<Node>();
	private NodeBuilder nb = new NodeBuilder();  
	
	public NetworkPanel() {
		setBackground(Color.white);
		nb.start();
	}
	
	@Override
	protected void paintComponent(Graphics arg0) {
		super.paintComponent(arg0);
		
		if (network != null) {
			for (Node n : network) {
				n.drawAgent(arg0);
				for (Node nei : n.neighbour) {
					arg0.setColor(Color.gray);
					arg0.drawLine(n.center.x, n.center.y, nei.center.x, nei.center.y);
				}
			}
		}	
		repaint();
	}
	
	class NodeBuilder extends Thread{
		private Random r = new Random();
		
		@Override
		public void run() {
			while(true) {
			int x = r.nextInt();
			int y = r.nextInt();
			
			Point center = new Point(x,y);
			
			network.add(new Node(center));
			}
		}
	}
	
}
