package view;

import java.awt.BorderLayout;
import java.awt.Dimension;

import javax.swing.JFrame;

public class Start extends JFrame {
	private static final long serialVersionUID = 1L;
	private NetworkPanel p;
	
	
	public Start() {
		super("Network");
		
		p = new NetworkPanel();
		setSize(new Dimension(300,300));
		BorderLayout bl =new BorderLayout();
		bl.addLayoutComponent(p, BorderLayout.CENTER);
		setLayout(bl);
		add(p);
		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
	}
	
	/*private List<Node> setUpNetwork() {
		List<Node> nodes = new ArrayList<Node>();
		
		Node n1 = new Node(new Point(3,3));
		Node n2 = new Node(new Point(10,50));
		Node n3 = new Node(new Point(100,15));
		
		n1.neighbour.add(n2);
		n1.neighbour.add(n3);
		
		nodes.add(n1);
		nodes.add(n2);
		nodes.add(n3);
		
		return nodes;
	}*/
	
	public static void main(String[] args) {
		new Start();
	}
}
