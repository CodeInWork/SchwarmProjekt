package agentsystem.soundnetwork;

import agentsystem.SimulationFrame;

public class Start extends SimulationFrame {
	private static final long serialVersionUID = -6825676026862389317L;

	public Start() {
		super("Networkrelations", null, 400, 400);
	}
	
	public static void main(String[] args) {
		new Start();
	}

}
