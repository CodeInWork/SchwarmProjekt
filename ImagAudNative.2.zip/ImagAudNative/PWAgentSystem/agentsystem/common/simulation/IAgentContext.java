package agentsystem.common.simulation;

public interface IAgentContext {
	
}
