package agentsystem.common.events;

import java.util.EventListener;

public interface IUpdatePanelListener extends EventListener {
	public void updatePanel();
}
