package agentsystem.common.events;

import java.util.EventObject;

public class UpdatePanelEvent extends EventObject{
	private static final long serialVersionUID = 1805888999810063250L;
	
	public UpdatePanelEvent(Object source) {
		super(source);
	}
	
	
}
